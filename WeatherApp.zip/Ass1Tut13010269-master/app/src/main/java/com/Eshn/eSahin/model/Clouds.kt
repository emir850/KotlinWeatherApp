package com.Eshn.eSahin.model


data class Clouds(
    val all: Int
)