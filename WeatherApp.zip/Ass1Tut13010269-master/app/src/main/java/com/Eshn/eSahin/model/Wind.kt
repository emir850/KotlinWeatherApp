package com.Eshn.eSahin.model


data class Wind(
    val deg: Int,
    val gust: Double,
    val speed: Double
)