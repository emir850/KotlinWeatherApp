package com.Eshn.eSahin.model


data class Coord(
    val lat: Double,
    val lon: Double
)