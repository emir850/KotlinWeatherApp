package com.Eshn.eSahin.model


data class Sys(
    val country: String,

)